#falta o historico do cliente,
import os          # biblioteca Sistema Operativo
import json
from datetime import datetime
from calendar import monthrange

lotacao = 15 # contante | a variavel nunca vai ser alterada durante a execução do programa
preco = [1.15,1,0.62] # valores do estacionamento
limitetempo = [0.75,2,0] # 0.75 3/4 de hora = 45 min isto serve para facilitar a vida
caminho = '.'  # serve para indicar onde é que está o ficheiro de historico

horasdeentrada = []
lugares = [lotacao] * 3 # array de 3 posiçoes com 15 || usar este array para estacionar os carros se tiver 0 ta livre e se tiver 1 ta ocupado
totaladquirido = [0] * 3

def menu_inicio():
    while True:
        limpar()
        sairparque()
        print(" ___________________________")
        print("|                           |")
        print("|-------- Bem-vindo --------|")
        print("|                           |")
        getTime() 
        print("|                           |")
        print("|------- Parquímetro -------|")
        print("|                           |")
        print("|      1. Administrador     |")
        print("|      2. Cliente           |")
        print("|      3. Opcôes            |")
        print("|      0. Sair              |")
        print("|___________________________|")
        n = input("Escolha a opção pretendida -> ")
        
        if n == '1':
            menu_admin()
            
        if n == '2':
            if parqueAberto():
                menu_cliente()
            else:
                print("O parque está fechado")
                input("-- Prima Enter para continuar -- ")
                         
        if n == '3':
            menu_opcoes() 
        
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i=="s":
                guardarestado()
                exit()

def limpar():    # Extraaaaaa
    if os.name == 'nt':     # windowns
        _= os.system('cls')
    else:                   # resto dos SOs
        _= os.system('clear')

def sairparque():
    tempoAtual = datetime.now() 
    timestamp = []  #guardar as horas do estacionamento 
    for i in list(tempoAtual.timetuple()):    #Conversão para array
        timestamp.append(int(i))

    apagar = []

    for i in horasdeentrada:
        if tempoAtual < i[0]:
            break
        escrita(f"{i[0]}: saiu o carro na zona: {i[1]}")
        apagar.append(i)
        lugares[i[1]] += 1 # incrementa a lotação dos lugares disponiveis

    for i in apagar:
        horasdeentrada.remove(i)

def getTime():
    dateTimeObj = datetime.now()
    dia = dateTimeObj.day
    mes = dateTimeObj.month
    ano = dateTimeObj.year
    hora = dateTimeObj.hour
    minuto = dateTimeObj.minute         
    diaSemana = dateTimeObj.today().weekday()  # 0 Segunda feira, 1 terça
    #Colocar o menu a mostrar correctamente
    if diaSemana == 0:
        diaTexto = "|        Segunda-feira      |"
    elif diaSemana == 1:
        diaTexto = "|        Terça-feira        |"
    elif diaSemana == 2:
        diaTexto = "|        Quarta-feira       |"
    elif diaSemana == 3:
        diaTexto = "|        Quinta-feira       |"
    elif diaSemana == 4:
        diaTexto = "|        Sexta-feira        |"
    elif diaSemana == 5:
        diaTexto = "|          Sábado           |"
    else:
        diaTexto = "|          Domingo          |"
    
    if dia < 10:                                              #corrigir o alinhamento do menu
        dia = '0' + str(dia)
    if mes < 10:                                              #corrigir o alinhamento do menu
        mes = '0' + str(mes)    
    print("|    Dia:", dia,"/", mes,"/", ano, "   |")
    print("|       Dia da Semana:      |")
    print(diaTexto)
    if minuto < 10:                                              #corrigir o alinhamento do menu
        minuto = '0' + str(minuto)
    if hora < 10:                                              #corrigir o alinhamento do menu
        hora = '0' + str(hora)
    print("|       Hora: ", hora, ":", minuto, "     |")
    
def parqueAberto(tempo=None):
    hoje = datetime.today()
    if tempo == None:
        #return hoje.weekday() < 5 and hoje.hour > 9 and hoje.hour < 20 or hoje == 5 and hoje.hour < 14 and hoje.hour > 9
        return True # <------------------------------------------------------------ DEBUG DEPOIS DA HORA DO FECHO. COMENTAR LINHA ANTERIOR
    hora = int(tempo)
    minuto =  int(round(tempo - hora,2) * 60)
    #Segunda a sexta das 9 às 20 e Aos sábados 9 às 14
    if hoje.weekday() == 5:
        if (minuto + hoje.minute > 60 or hora > 1 )and hoje.hour + 1 >= 14:
            return tempo + 24 - hoje.hour + 9 + 24 #horas para acabar o dia, 24h do Domingo 9 horas para abrir na segunda 
        else: return tempo
    else:
        if (minuto + hoje.minute > 60 or hora > 1 ) and hoje.hour + 1 >= 20:
            return tempo + 24 - hoje.hour + 9  #Tempo até à próxima abertura
    return tempo

# ------ Menu Administrador ------

def menu_admin():
    while True:
        limpar()
        print(" ________________________")
        print("|                        |")
        print("|---- Administrador  ----|")
        print("|                        |")
        print("|    1. Ver Zonas        |")
        print("|    2. Ver histórico    |")
        print("|    3. Ver máquinas     |")
        print("|    4. Voltar           |")
        print("|    0. Sair             |")
        print("|________________________|")
        n = input("Escolha a opção pretendida -> ")
        
        if n == '1':
            ver_zonasadm()
            # aparecem as 3 zonas e quantos lugares disponiveis existem
        
        if n == '2':
            leitura()
            input("-- Prima Enter para continuar -- ")
            
        if n == '3':
            ver_maquinas()
            #aparece quanto dinheiro tem nas máquinas (diário + total)
            
        if n == '4':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i == "s":
                guardarestado()
                exit() 

def ver_zonasadm():
    while True:
        limpar()
        print(" ________________________")
        print("|                        |")
        print("|------ Ver Zonas -------|")
        print("|                        |")
        print("|       1. Zona 1        |")   # zona 1 - lugares e €
        print("|       2. Zona 2        |")
        print("|       3. Zona 3        |")
        print("|       4. Voltar        |")
        print("|       0. Sair          |")
        print("|________________________|") 
        n = input("Escolha a opção pretendida -> ")   
        
        if n == '1':
            print("Zona 1:")
            print(f"Preço: {preco[0]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[0]* 60} minutos") # *60 ta a passar de horas para minutos
            print(f"Lugares: \033[93m{lugares[0]}\033[0m de \033[36m{lotacao}\033[0m") # formatar a string e introduzir uma variavel
            
        if n == '2':
            print("Zona 2:")
            print(f"Preço: {preco[1]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[1]} horas")
            print(f"Lugares: \033[93m{lugares[1]}\033[0m de \033[36m{lotacao}\033[0m") # formatar a string e introduzir uma variavel      
            
        if n == '3':            
            print("Zona 3:")
            print(f"Preço: {preco[2]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[2]}")
            print(f"Lugares: \033[93m{lugares[2]}\033[0m de \033[36m{lotacao}\033[0m") # formatar a string e introduzir uma variavel
        
        if n == '4':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i == "s":
                guardarestado()
                exit()
        if n != '' :         
            input("-- Prima Enter para continuar -- ")

def leitura(): #extraaaaaaaaaaaaaaa
    try: #caso o ficheiro nao exista e caso o ficheiro não tenha nada dentro
        ficheiro = open(caminho+"/historico.log","r") # isto abre o ficheiro em modo leitura
        contador = 0
        for linha in ficheiro:
            print (linha)
            contador += 1
        ficheiro.close()
        if contador == 0 : #extraaaaaaaaaa    
            raise Exception
    except:
        print("Não existe historico.") 

def escrita(texto):
    try:    #extraaaaaaaaaaaaaaaaaaa
        ficheiro = open(caminho+"/historico.log","a") # isto abre o ficheiro em modo leitura
    except:                          # se o ficheiro não existir ele cria
        ficheiro = open(caminho+"/historico.log","w")
    ficheiro.write("\n" + texto)
    ficheiro.close()

def ver_maquinas():
    while True:
        limpar()
        print(" _______________________")
        print("|                       |")
        print("|---- Ver Máquinas  ----|")
        print("|                       |")
        print("|   1. Máquina Zona 1   |")              
        print("|   2. Máquina Zona 2   |")
        print("|   3. Máquina Zona 3   |")
        print("|   4. Voltar           |")
        print("|   0. Sair             |")
        print("|_______________________|")
        n = input("Escolha a opção pretendida -> ") 
        
        if n == '1':
            print(f"Valor monetário = {totaladquirido[0]}€")
            
        if n == '2':
            print(f"Valor monetário = {totaladquirido[1]}€")
            
        if n == '3':
            print(f"Valor monetário = {totaladquirido[2]}€")
            
        if n == '4':
            break
        
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i=="s":
                guardarestado()
                exit()
        if n != '' : 
            input("-- Prima Enter para continuar -- ")

# ------ Menu Clientes ------

def menu_cliente():
    while True:
        limpar()
        print(" __________________________")
        print("|                          |")
        print("|-------- Cliente ---------|")
        print("|                          |")
        print("|      1. Estacionar       |")
        print("|      2. Ver zonas        |")
        print("|      3. Ver histórico    |")
        print("|      4. Voltar           |")
        print("|      0. Sair             |")
        print("|__________________________|")
        n = input("Escolha a opção pretendida -> ")
        
        if n == '1':
            estacionar()
            # ver dia da semana; escolher zona; lugares disponíveis; pedir a moeda ao utilizador; fazer conta; imprimir ticket;
            
        if n == '2':
            ver_zonascliente() 
            
        if n == '3':
            # quantos já entraram; em que lugares ficaram, quanto €
            print("Já entraram: ",lotacao * 3 - sum(lugares)) # Lugares sao 3 andares disponiveis | sum = soma de todos os lugares disponiveis porque esta contar todos
            print("Lugares disponiveis: ",sum(lugares))
            print("Valor monetário adquirido: ",totaladquirido)
            input("-- Prima Enter para continuar -- ")
        
        if n == '4':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i=="s":
                guardarestado()
                exit()

def estacionar():
    while True:
        limpar()
        print(" ________________________")
        print("|                        |")
        print("|------ Estacionar ------|")
        print("|                        |")
        print("|  1. Zona 1  (1.15€/h)  |")
        print("|  2. Zona 2  (1€/h)     |")
        print("|  3. Zona 3  (0.62€/h)  |")
        print("|       4. Voltar        |")
        print("|       0. Sair          |")
        print("|________________________|") 
        n = input("Escolha a opção pretendida -> ")
        if n == '1' or n == '2' or n == '3':
            n = int(n)
            n -= 1
            if lugares[n] > 0:
                calculodepreco(n)
            else:
                print(f"Zona {n+1} está cheia.")
                input("-- Prima Enter para continuar -- ")
            
        if n == '4':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i=="s":
                guardarestado()
                exit()

def calculodepreco(zona):
    global totaladquirido
    while True:
        moedas = input("Para regressar prima Enter.\nIntroduza as moedas: ")
        try:
            moedas = eval(moedas)
        except:
            break
        if fazerVerificação(moedas): #retorna verdadeiro ou falso
            tempoestacionamento = parqueAberto(moedas / preco[zona])  # dá o tempo de estacionamento sem cobrar em horas fechadas
            hora = int(tempoestacionamento)
            minuto =  int(round(tempoestacionamento - hora,2) * 60)   # 
            if minuto < 10:                                              #corrigir o alinhamento do menu | Acrescenta os zeros
                minuto = '0' + str(minuto)
            if hora < 10:                                              #corrigir o alinhamento do menu | Acrescenta os zeros
                hora = '0' + str(hora)
            if(zona == 2 or limitetempo[zona] >= tempoestacionamento):
                n = input(f"Inseriu {moedas} € \nTempo de estacionamento: {hora}h{minuto}m\nContinuar?\t 1 - Sim \t 0 - Não \t") # 
                if(n == '1'):
                    lugares[zona] -= 1
                    totaladquirido[zona] += moedas
                    imprimirticket(zona + 1,tempoestacionamento,moedas)
                    return       
            else:
                print(f"Esta zona tem o tempo limite de {int(limitetempo[zona] * 60)} minutos.")
                print(f"O valor monetário inserido dá um tempo de estacionamento de {hora}h {minuto}")
                print(f"O preço equivalente ao tempo limite é {round(limitetempo[zona] * preco[zona],2)}€")
        else:
            print("Só aceita moedas superiores a 0.02€.")

def fazerVerificação(trocos):
    if trocos == 0: return False
    moedas = [2, 1, 0.5, 0.2, 0.1, 0.05] #A máquina aceita moedas superiores a 0.02€
    for i in range(len(moedas)):  # percorre-se ambos os arrays (quantias e resultado)
        trocos = round(trocos % moedas[i], 2)
    if trocos == 0: return True
    return False

def imprimirticket(zona,tempoestacionamento,valor):
    tempoAtual = datetime.now() 
    timestamp = []  #guardar as horas do estacionamento 
    for i in list(tempoAtual.timetuple()):    #Conversão para array
        timestamp.append(int(i))

    log = f"{tempoAtual.strftime('%Y-%m-%d %H:%M:%S')}: Entrou carro na zona: {zona}"
    #Cálculo do tempo de estacionamento
    
    hora = int(tempoestacionamento)
    minuto =  int(round(tempoestacionamento - hora,2) * 60) 
    
    timestamp[3]  += hora
    timestamp[4]  += minuto

    #Verificação para garantir que as datas estão dentro dos limites
    while timestamp[4] > 59:
        timestamp[3] += 1
        timestamp[4] -= 60

    while timestamp[3] > 23:
        timestamp[3] -= 24
        timestamp[2] += 1
    
    while timestamp[2] > monthrange(tempoAtual.year, tempoAtual.month)[1]:
        timestamp[1] += 1 
        timestamp[2] -= monthrange(tempoAtual.year, tempoAtual.month)[1]
    
    while timestamp[1] > 12:
        timestamp[1] -= 12
        timestamp[0] += 1

    #conversão de volta para datetime com as contas feitas
    timestamp = datetime(*timestamp[:6]) #*Significa todos os valores da lista, neste caso da posição 0 até à 6 (não incluída)

    print(" ___________________________")
    print("|                           |")
    getTime() 
    print("|                           |")
    print(f"|---- Parquímetro ID: {zona} ----|")
    print("|                           |")
    print("|      Valor introduzido    |")
    print(f"|          {valor}€            |")
    print("|       válido até:         |")
    print(f"|         {timestamp.strftime('%d/%m/%Y')}        |")
    print(f"|         {timestamp.strftime('%H:%M:%S')}          |")
    print("|___________________________|")
    escrita(log)
    horasdeentrada.append([timestamp,zona])
    horasdeentrada.sort(reverse=True) # maior para o msis pequeno reverese=True
    input("-- Prima qualquer tecla para continuar -- ")

def ver_zonascliente():
    while True:
        limpar()
        print(" ________________________")
        print("|                        |")
        print("|------ Ver Zonas -------|")
        print("|                        |")
        print("|       1. Zona 1        |")     # mostra lugares
        print("|       2. Zona 2        |")
        print("|       3. Zona 3        |")
        print("|       4. Voltar        |")
        print("|       0. Sair          |")
        print("|________________________|") 
        n = input("Escolha a opção pretendida -> ") 
        
        if n == '1':
            print("Zona 1:")
            print(f"Preço: {preco[0]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[0]* 60} minutos") # *60 ta a passar de horas para minutos
            print(f"Lugares: {lugares[0]}") # formatar a string e introduzir uma variavel
            
        if n == '2':
            print("Zona 2:")
            print(f"Preço: {preco[1]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[1]} horas")
            print(f"Lugares: {lugares[1]}") # formatar a string e introduzir uma variavel      
            
        if n == '3':            
            print("Zona 3:")
            print(f"Preço: {preco[2]}€/hora") # formatar a string e introduzir uma variavel
            print(f"Duração máxima: {limitetempo[2]}")
            print(f"Lugares: {lugares[2]}") # formatar a string e introduzir uma variavel        
            
        if n == '4':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i == "s":
                guardarestado()
                exit()
        input("-- Prima Enter para continuar -- ")

# ------ Menu Opções ------

def menu_opcoes():
    while True:
        limpar()
        print(" _______________________")
        print("|                       |")
        print("|------  Opções   ------|")
        print("|                       |")
        print("|   1. Ver Criadores    |")
        print("|   2. Ver Mais         |")
        print("|   3. Voltar           |")
        print("|   0. Sair             |")
        print("|_______________________|")  
        n = input("Escolha a opção pretendida -> ")  
        
        if n == '1':
            print("Turma B:")
            print("- João Afonso Sardinha Reis")
            print("nº 2046520")
            print("")
            print("- Luís António Ferro de Almeida")
            print("nº 2038820")  
            print("")
            print("- Érica Rubina Brito Camacho")
            print("nº 2047720")
            
        if n == '2':
            print ("Unidade Curricular: Introdução à Programação")
            print ("Docentes:")
            print ("- Ana Caraban") 
            print("- Frederica Gonçalves")
            print("")
            print ("Projeto - 2020/2021")
        
        if n == '3':
            break
            
        if n == '0':
            i = str(input("Deseja sair da aplicação? S/N -> "))
            if i == "S" or i=="s":
                guardarestado()
                exit()
        input("-- Prima Enter para continuar -- ")

# ------ ------
                      
def conversorData(data, reverter=False):
    result=[]
    if reverter == False:
        for i in data:
            result.append([list(i[0].timetuple()), i[1]])
        return result
    
    for i in data:
        result.append([datetime(*i[0][:6]),i[1]]) 
    return result

def guardarestado():
    try:
        estado = {             #dicionario com o estado de todas as variaveis EXXXTRA
            "lotacao":lotacao,
            "lugares":lugares,
            "preco":preco,
            "totaladquirido":totaladquirido,
            "limitetempo":limitetempo,
            "horasdeentrada": conversorData(horasdeentrada)
                }
        json_file = open(caminho+"/estado.json","w")
        json.dump(estado,json_file)
    except:
        print("Ocorreu um erro ao guardar o estado do programa.")
    
def carregarestado():
    global lotacao,lugares,preco,totaladquirido,limitetempo,horasdeentrada
    try:
        json_file = open(caminho+"/estado.json","r")  # carrega o estado das variaveis EXXXTRA
        estado = json.load(json_file)
        lotacao = estado["lotacao"]
        lugares = estado["lugares"]
        preco = estado["preco"]
        totaladquirido = estado["totaladquirido"]
        limitetempo = estado["limitetempo"]
        horasdeentrada = conversorData(estado["horasdeentrada"], True)
    except:
        pass  #vai ignorar a exepção

carregarestado()

menu_inicio()
    